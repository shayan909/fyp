from MedicineRecommendation import recommmendation
from DiseaseIdentification import identifier


def driver(inputCurrentMedicine, inputCurrentIllness, inputSymptoms):
    predictions = []
    inputSymptomsOrDiseases = [] # Symptoms from user + Diseases Identified for Medicine Recommendation
    predictions = identifier(inputSymptoms)
    if predictions:
        predictionString = 'You might be experiencing these problems/diseases: ' + ' '.join([str(elem) for elem in predictions])  # turn list into string
    else:
        predictionString = "Sorry I couldn't identify any disease, either there is none or there is something that I don't " \
                           "know about."
    print(predictionString)
    inputSymptomsOrDiseases.extend(inputSymptoms)
    inputSymptomsOrDiseases.extend(predictions)
    recommmendationString = recommmendation(inputSymptomsOrDiseases, inputCurrentMedicine, inputCurrentIllness)
    recommmendationString = ' '.join(recommmendationString)  # Convert tuple to string
    return predictionString, recommmendationString


# # Testing
# inputCurrentMedicine = ['Paracetamol']  # To be taken from chatbot
# inputCurrentIllness = ['fever']  # To be taken from chatbot
# inputSymptoms = []  # To be taken from chatbot
# predictionDisease, recommmendationDrug = driver(inputCurrentMedicine, inputCurrentIllness, inputSymptoms)
# print(predictionDisease, recommmendationDrug)
