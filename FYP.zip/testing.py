import pandas as pd

class simpleSelection:
    def fit(self, features, targetName):
        symptomsOfDataSet = []
        for index, column in enumerate(features.columns):
            symptomsOfDataSet.append(features.iat[0, index])
        self.features = symptomsOfDataSet
        self.targetName = targetName.iloc[0]
    def predict(self, inputSymptoms):
        inputSymptoms = [item for sublist in inputSymptoms for item in sublist]
        for index in range(len(inputSymptoms)):
            if self.features[index] == inputSymptoms[index]:
                return self.targetName

diseases = pd.read_csv("Disease Dataset.csv")
df = pd.DataFrame(diseases)

# DiseaseClasses = pd.read_csv("Disease Classes.csv")
# Groups = list(DiseaseClasses['Groups'])
dfNew = pd.DataFrame()
dfNew = dfNew.append(df.loc[(df['TARGET'] == x)])
model = simpleSelection()
target = dfNew['TARGET']
symptoms = dfNew.drop('TARGET', axis='columns')
model = simpleSelection()
model.fit(symptoms, target)

inputSymptoms = ['Phlegm', 'Fever', 'Sinus_Pressure', 'Runny_Nose', 'Long_Term_Breathing_Or_Wheezing', 'Cough', 'sharp_pain_when_weight_is_put_on_joint', 'Gas']
inputSymptoms = [x.lower() for x in inputSymptoms]
inputSymptomsIntegers = list(df.columns.drop('TARGET'))
inputSymptomsIntegers = [x.lower() for x in inputSymptomsIntegers]
for i in range(len(inputSymptomsIntegers)):
    found = False
    for n in range(len(inputSymptoms)):
        if inputSymptoms[n] == inputSymptomsIntegers[i]:
            inputSymptomsIntegers[i] = 1
            found = True
    if not found:
        inputSymptomsIntegers[i] = 0
print("Input:", inputSymptomsIntegers)

print(model.predict([inputSymptomsIntegers]))
