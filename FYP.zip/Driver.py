from DiseaseClasses import Identification
from MedicineRecommendation import recommmendation


inputSymptomsOrDiseases = ['COUGH', 'hives'] # Symptoms from user + Diseases Identified for Medicine Recommendation
inputCurrentMedicine = ['Ibuprofen']
inputCurrentIllness = ['Heart Disease']
inputSymptoms = ['Phlegm', 'Fever', 'Sinus_Pressure', 'Runny_Nose', 'Long_Term_Breathing_Or_Wheezing', 'Cough', 'sharp_pain_when_weight_is_put_on_joint', 'Gas']
# predictions = Identification(inputSymptoms)
# predictionsString = 'You might have:' + ' '.join([str(elem) for elem in predictions])  # list turn into string
# print(predictionsString)
inputSymptomsOrDiseases.extend(inputSymptoms)
print((recommmendation(inputSymptomsOrDiseases, inputCurrentMedicine, inputCurrentIllness)))

