import sqlite3
conn = sqlite3.connect('chatbot.db')

DrugsIndications = [(1, 12), (2, 10), (1, 8), (2, 9)]
DrugsIndicationsDict = {}
for i in DrugsIndications:
    for n in DrugsIndications:
        if i[0] == n[0]:
            DrugsIndicationsDict.setdefault(i[0], [])
            DrugsIndicationsDict[i[0]].append(n[1])
    for x in DrugsIndications:  # Removing all the values that have been worked on
        if x[0] == i[0]:
            DrugsIndications.remove(x)
print(DrugsIndicationsDict)
Drugs = []
Indications = []
for key in DrugsIndicationsDict.keys():
    cursor = conn.execute('SELECT BRAND.name, DRUG.name, ADULT_USAGE.DOSE, ADULT_USAGE.ROUTE, BRAND.FORM, '
                          'BRAND.MG, BRAND.RETAILPRICE, ADULT_USAGE.INSTRUCTION, DRUG.WARNING '

                          'FROM DRUG '
                          'INNER JOIN ADULT_USAGE ON DRUG.DID = ADULT_USAGE.DID '
                          'INNER JOIN BRAND ON DRUG.DID = BRAND.DID '
                          'WHERE DRUG.DID=?', (key,))
    Drugs.append(cursor.fetchone())
    for value in DrugsIndicationsDict.get(key):
        cursor = conn.execute('SELECT DISEASE_NAME FROM INDICATION WHERE IndicationID=?', (value,))
        Indications.append(cursor.fetchone())
print(Drugs)
print(Indications)