import sqlite3
conn = sqlite3.connect('chatbot.db')

DistinctDrugIndicationSet = [(1, 12), (2, 10), (1, 8), (2, 9)]
DistinctDrugIndicationSetDict = {}
for i in DistinctDrugIndicationSet:
    for n in DistinctDrugIndicationSet:
        if i[0] == n[0]:
            DistinctDrugIndicationSetDict.setdefault(i[0], [])
            DistinctDrugIndicationSetDict[i[0]].append(n[1])
    for x in DistinctDrugIndicationSet:  # Removing all the values that have been worked on
        if x[0] == i[0]:
            DistinctDrugIndicationSet.remove(x)
print(DistinctDrugIndicationSetDict)
Drugs = []
Indications = []
for key in DistinctDrugIndicationSetDict.keys():
    cursor = conn.execute('SELECT BRAND.name, DRUG.name, ADULT_USAGE.DOSE, ADULT_USAGE.ROUTE, BRAND.FORM, '
                          'BRAND.MG, BRAND.RETAILPRICE, ADULT_USAGE.INSTRUCTION, DRUG.WARNING '

                          'FROM DRUG '
                          'INNER JOIN ADULT_USAGE ON DRUG.DID = ADULT_USAGE.DID '
                          'INNER JOIN BRAND ON DRUG.DID = BRAND.DID '
                          'WHERE DRUG.DID=?', (key,))
    Drugs.append(cursor.fetchone())
    for value in DistinctDrugIndicationSetDict.get(key):
        cursor = conn.execute('SELECT DISEASE_NAME FROM INDICATION WHERE IndicationID=?', (value,))
        Indications.append(cursor.fetchone())
print(Drugs)
print(Indications)