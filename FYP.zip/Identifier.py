import sqlite3

# conn = sqlite3.connect('chatbot.db')
# print("Connection Opened!")
# command = "SELECT * from medicine"
# result=conn.execute(command)
# for i in result:
#     print(i)
import pandas as pd
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier


diseases = pd.read_csv("Disease Dataset.csv")
mixedSymptoms=diseases.drop('TARGET',axis='columns')
target=diseases['TARGET']
#print(target)
#print(mixedSymptoms)
#print(mixedSymptoms.columns)
# inputs=['Fever','Aches']
# mixedSymptomsList1 = mixedSymptoms.columns.tolist() #Convert MixedSymptoms To list
# inputSymptoms = mixedSymptomsList1
# for i in range(len(mixedSymptomsList1)):
#     for n in range(len(inputs)):
#         if inputs[n] == mixedSymptomsList1[i]:
#             print("Found")
#             inputSymptoms[i] = 1

#print(mixedSymptomsList1) #print list


inputSymptoms = [[1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]#Fever and Aches


class MixedSymptoms:
    def predictDisease(inputSymptoms, mixedSymptoms, target):
        model = DecisionTreeClassifier()
        model.fit(mixedSymptoms,target)
        #model.score(mixedSymptoms, target)
        print(model.predict(inputSymptoms))
        #print(mixedSymptoms)
MixedSymptoms1 = MixedSymptoms.predictDisease(inputSymptoms, mixedSymptoms, target)


